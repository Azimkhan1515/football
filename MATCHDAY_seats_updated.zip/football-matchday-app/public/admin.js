(() => {
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
  const money = (value) => `${Number(value || 0).toLocaleString("ru-RU")} ₸`;
  let csrfToken = "";
  let currentUser = null;
  let products = [], orders = [], users = [], movements = [];
  let notifyTimer;

  function notice(message, kind = "") {
    const box = $("#notice");
    box.textContent = message;
    box.className = `banner ${kind}`;
    box.classList.remove("hidden");
    clearTimeout(notifyTimer);
    notifyTimer = setTimeout(() => box.classList.add("hidden"), 6000);
  }
  async function api(url, options = {}) {
    const method = (options.method || "GET").toUpperCase();
    const headers = { ...(options.body ? { "Content-Type": "application/json" } : {}), ...(options.headers || {}) };
    if (!["GET", "HEAD", "OPTIONS"].includes(method) && csrfToken) headers["x-csrf-token"] = csrfToken;
    const response = await fetch(url, { ...options, method, headers, credentials: "same-origin" });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `Ошибка сервера (${response.status})`);
    return data;
  }
  async function refreshCsrf() {
    const result = await api("/api/auth/me");
    csrfToken = result.csrfToken || "";
    currentUser = result.user;
    return result;
  }
  const categoryNames = { ucl: "Лига чемпионов", premier: "АПЛ", la_liga: "Ла Лига", serie_a: "Серия А", kz_premier: "Казахстан", international: "Сборные" };
  function showPage(name) {
    $$(".page").forEach((section) => section.classList.toggle("hidden", section.id !== `page-${name}`));
    $$("#adminNav button").forEach((button) => button.classList.toggle("active", button.dataset.page === name));
    const loaders = { overview: loadOverview, products: loadProducts, orders: loadOrders, users: loadUsers, movements: loadMovements, mail: loadMail };
    loaders[name]?.().catch((error) => notice(error.message, "error"));
  }
  function setAuthorized(user) {
    currentUser = user;
    $("#loginView").classList.add("hidden");
    $("#adminView").classList.remove("hidden");
    $("#adminName").textContent = `${user.name} · администратор`;
    $("#adminName").classList.remove("hidden");
    $("#logout").classList.remove("hidden");
    showPage("overview");
  }
  function setUnauthorized(message = "") {
    currentUser = null;
    $("#adminView").classList.add("hidden");
    $("#adminName").classList.add("hidden");
    $("#logout").classList.add("hidden");
    $("#loginView").classList.remove("hidden");
    if (message) {
      $("#loginMessage").textContent = message;
      $("#loginMessage").className = "banner error";
    }
  }
  async function loadOverview() {
    const [summary, latest] = await Promise.all([api("/api/admin/overview"), api("/api/admin/orders")]);
    $("#metrics").innerHTML = [
      ["Матчей в афише", summary.products], ["Билетов доступно", summary.units],
      ["Мало билетов", summary.lowStock], ["Заказов / регистраций", `${summary.orderCount} / ${summary.userCount}`],
    ].map(([label, value]) => `<article class="metric"><span>${escapeHtml(label)}</span><strong>${Number(value || 0).toLocaleString("ru-RU")}</strong></article>`).join("");
    $("#recentOrders").innerHTML = latest.orders.slice(0, 7).map((order) => `<tr><td>${escapeHtml(order.id)}</td><td>${escapeHtml(order.accountName)}<br><span class="note">${escapeHtml(order.email)}</span></td><td>${money(order.total)}</td><td><span class="status ${order.canceled_at ? "bad" : ""}">${escapeHtml(order.status)}</span></td></tr>`).join("") || '<tr><td colspan="4" class="empty">Пока заказов нет.</td></tr>';
  }
  async function loadProducts() {
    products = (await api("/api/admin/products")).products;
    drawProducts();
  }
  function drawProducts() {
    const q = $("#productSearch").value.trim().toLocaleLowerCase("ru-RU");
    const filtered = products.filter((p) => [p.name, p.brand, p.category].join(" ").toLocaleLowerCase("ru-RU").includes(q));
    $("#productsRows").innerHTML = filtered.map((p) => {
      const low = p.stock <= 3;
      return `<tr><td><div class="product-cell"><img loading="lazy" src="${escapeHtml(p.image)}" alt=""><span><b>${escapeHtml(p.name)}</b><small>${escapeHtml(p.brand)}${p.active ? "" : " · скрыт"}</small></span></div></td><td>${escapeHtml(categoryNames[p.category] || p.category)}</td><td>${money(p.price)}</td><td><span class="status ${p.stock === 0 ? "bad" : low ? "wait" : "ok"}">${p.stock} билетов</span></td><td><div class="row-buttons"><button class="button small" data-edit-product="${p.id}">Изменить</button><button class="button small" data-stock-product="${p.id}">Билеты</button><button class="button small ${p.active ? "danger" : ""}" data-toggle-product="${p.id}">${p.active ? "Скрыть" : "Вернуть"}</button></div></td></tr>`;
    }).join("") || '<tr><td colspan="5" class="empty">Матчы не найдены.</td></tr>';
  }
  async function loadOrders() {
    orders = (await api("/api/admin/orders")).orders;
    drawOrders();
  }
  const statuses = ["Забронирован (демо)", "Подтверждён", "Билеты готовы", "Матч завершён", "Отменён"];
  function drawOrders() {
    const q = $("#orderSearch").value.trim().toLocaleLowerCase("ru-RU");
    const filtered = orders.filter((o) => [o.id, o.accountName, o.email, o.customer_name, o.phone].join(" ").toLocaleLowerCase("ru-RU").includes(q));
    $("#ordersRows").innerHTML = filtered.map((o) => {
      const items = o.items.map((i) => `${escapeHtml(i.name)} × ${i.qty}`).join("<br>");
      const select = statuses.map((s) => `<option value="${escapeHtml(s)}" ${o.status === s ? "selected" : ""}>${escapeHtml(s)}</option>`).join("");
      return `<tr><td><b>${escapeHtml(o.id)}</b><br>${escapeHtml(o.accountName || o.customer_name)}<br><span class="note">${escapeHtml(o.email)} · ${escapeHtml(o.phone)}</span><br><span class="note">${new Date(o.created_at).toLocaleString("ru-RU")}</span></td><td class="items">${items}<br><span class="note">${escapeHtml(o.city)}, ${escapeHtml(o.address)}</span></td><td>${money(o.total)}</td><td><select class="input" data-order-status="${escapeHtml(o.id)}" ${o.canceled_at ? "disabled" : ""}>${select}</select></td><td><button class="button small danger" data-cancel-order="${escapeHtml(o.id)}" ${o.canceled_at || o.status === "Матч завершён" ? "disabled" : ""}>Отменить</button></td></tr>`;
    }).join("") || '<tr><td colspan="5" class="empty">Заказов пока нет.</td></tr>';
  }
  async function loadUsers() {
    users = (await api("/api/admin/users")).users;
    drawUsers();
  }
  function drawUsers() {
    const q = $("#userSearch").value.trim().toLocaleLowerCase("ru-RU");
    const filtered = users.filter((u) => `${u.name} ${u.email}`.toLocaleLowerCase("ru-RU").includes(q));
    $("#usersRows").innerHTML = filtered.map((u) => `<tr><td><input class="input" data-user-name="${u.id}" value="${escapeHtml(u.name)}"><br><input class="input" style="margin-top:5px" type="email" data-user-email="${u.id}" value="${escapeHtml(u.email)}"></td><td><span class="status">${escapeHtml(u.role)}</span></td><td>${Number(u.orderCount || 0)}</td><td><span class="status ${u.isActive ? "ok" : "bad"}">${u.isActive ? "Активен" : "Отключён"}</span></td><td><div class="row-buttons"><button class="button small" data-save-user="${u.id}">Сохранить</button><button class="button small" data-toggle-user="${u.id}" ${u.id === currentUser.id ? "disabled" : ""}>${u.isActive ? "Отключить" : "Включить"}</button></div></td></tr>`).join("") || '<tr><td colspan="5" class="empty">Пользователи не найдены.</td></tr>';
  }
  async function loadMovements() {
    movements = (await api("/api/admin/movements")).movements;
    const byId = new Map(products.map((p) => [p.id, p.name]));
    $("#movementsRows").innerHTML = movements.map((m) => `<tr><td>${new Date(m.created_at).toLocaleString("ru-RU")}</td><td>${escapeHtml(m.product_name || byId.get(m.product_id) || "Матч")}</td><td>${escapeHtml(m.kind)}</td><td>${m.delta > 0 ? "+" : ""}${Number(m.delta)}</td><td>${Number(m.balance)} билетов</td><td>${escapeHtml(m.note)}</td></tr>`).join("") || '<tr><td colspan="6" class="empty">Записей пока нет.</td></tr>';
  }
  async function loadMail() {
    const data = await api("/api/admin/mail/status");
    const verified = data.verification?.ok;
    $("#mailSummary").innerHTML = `<div class="panel-head"><div><h3>Получатель: ${escapeHtml(data.recipient)}</h3><p>Отправитель: ${escapeHtml(data.sender || "не настроен")}</p></div><span class="status ${verified ? "ok" : data.configured ? "wait" : "bad"}">${verified ? "SMTP подключён" : data.configured ? "Ошибка SMTP" : "Нужна настройка"}</span></div><p class="note">${escapeHtml(data.verification?.error || "Письма о заказах, отменах и смене статуса будут идти на этот адрес.")}</p>`;
    $("#mailRows").innerHTML = data.notifications.map((n) => `<tr><td>${new Date(n.created_at).toLocaleString("ru-RU")}</td><td>${escapeHtml(n.subject)}<br><span class="note">${escapeHtml(n.order_id)}</span></td><td>${escapeHtml(n.recipient)}</td><td><span class="status ${n.status === "sent" ? "ok" : n.status === "failed" ? "bad" : "wait"}">${escapeHtml(n.status)}</span></td><td>${escapeHtml(n.error || (n.sent_at ? "Отправлено " + new Date(n.sent_at).toLocaleString("ru-RU") : "Ожидает настройки SMTP"))}</td></tr>`).join("") || '<tr><td colspan="5" class="empty">Писем пока нет.</td></tr>';
  }
  function resetProductForm() {
    $("#productForm").reset(); $("#productId").value = ""; $("#productEditorTitle").textContent = "Новый матч";
    $("#productEditor").classList.remove("hidden"); $("#productEditor").scrollIntoView({ behavior: "smooth", block: "center" });
  }
  function editProduct(product) {
    const form = $("#productForm");
    $("#productId").value = product.id; $("#productEditorTitle").textContent = `Изменить: ${product.name}`;
    for (const key of ["name", "brand", "category", "price", "stock", "badge", "image", "subtitle", "description", "warranty", "delivery"]) form.elements[key].value = product[key] ?? "";
    form.elements.tags.value = (product.tags || []).join(", ");
    $("#productEditor").classList.remove("hidden"); $("#productEditor").scrollIntoView({ behavior: "smooth", block: "center" });
  }
  async function refreshAll() {
    await Promise.all([loadOverview(), loadProducts(), loadOrders()]);
  }

  $("#loginForm").addEventListener("submit", async (event) => {
    event.preventDefault(); $("#loginSubmit").disabled = true;
    try {
      await api("/api/auth/login", { method: "POST", body: JSON.stringify({ email: $("#loginEmail").value, password: $("#loginPassword").value }) });
      const auth = await refreshCsrf();
      if (auth.user?.role !== "admin") { await api("/api/auth/logout", { method: "POST" }); csrfToken = ""; throw new Error("Этот аккаунт не имеет роли администратора."); }
      setAuthorized(auth.user);
    } catch (error) {
      $("#loginMessage").textContent = error.message;
      $("#loginMessage").className = "banner error";
      $("#loginMessage").classList.remove("hidden");
    } finally { $("#loginSubmit").disabled = false; }
  });
  $("#logout").onclick = async () => { try { await api("/api/auth/logout", { method: "POST" }); } catch {} csrfToken = ""; setUnauthorized(); };
  $("#adminNav").onclick = (event) => { const button = event.target.closest("[data-page]"); if (button) showPage(button.dataset.page); };
  document.addEventListener("click", async (event) => {
    const go = event.target.closest("[data-go]"); if (go) return showPage(go.dataset.go);
    if (event.target.closest("[data-refresh]")) return refreshAll().catch((e) => notice(e.message, "error"));
    const edit = event.target.closest("[data-edit-product]");
    if (edit) return editProduct(products.find((p) => p.id === Number(edit.dataset.editProduct)));
    if (event.target.closest("#newProduct")) return resetProductForm();
    if (event.target.closest("#cancelProductEdit")) return $("#productEditor").classList.add("hidden");
    const stock = event.target.closest("[data-stock-product]");
    if (stock) {
      const item = products.find((p) => p.id === Number(stock.dataset.stockProduct));
      const value = prompt(`Укажи число доступных билетов на матч «${item.name}»:`, String(item.stock));
      if (value === null) return;
      const amount = Number(value);
      if (!Number.isSafeInteger(amount) || amount < 0) return notice("Количество билетов должно быть целым числом от нуля.", "error");
      try { await api(`/api/admin/products/${item.id}`, { method: "PATCH", body: JSON.stringify({ ...item, stock: amount }) }); await loadProducts(); await loadMovements(); await loadOverview(); notice("Количество билетов сохранено в SQLite.", "success"); }
      catch (e) { notice(e.message, "error"); }
      return;
    }
    const toggleProduct = event.target.closest("[data-toggle-product]");
    if (toggleProduct) {
      const item = products.find((p) => p.id === Number(toggleProduct.dataset.toggleProduct));
      try { await api(`/api/admin/products/${item.id}`, { method: "PATCH", body: JSON.stringify({ ...item, active: !item.active }) }); await loadProducts(); await loadOverview(); notice("Каталог обновлён.", "success"); }
      catch (e) { notice(e.message, "error"); }
      return;
    }
    const saveUser = event.target.closest("[data-save-user]");
    if (saveUser) {
      const id = Number(saveUser.dataset.saveUser);
      try { await api(`/api/admin/users/${id}`, { method: "PATCH", body: JSON.stringify({ name: $(`[data-user-name="${id}"]`).value, email: $(`[data-user-email="${id}"]`).value }) }); await loadUsers(); notice("Данные пользователя сохранены.", "success"); }
      catch (e) { notice(e.message, "error"); }
      return;
    }
    const toggleUser = event.target.closest("[data-toggle-user]");
    if (toggleUser) {
      const u = users.find((item) => item.id === Number(toggleUser.dataset.toggleUser));
      try { await api(`/api/admin/users/${u.id}`, { method: "PATCH", body: JSON.stringify({ name: u.name, email: u.email, isActive: !u.isActive }) }); await loadUsers(); await loadOverview(); notice("Статус аккаунта обновлён.", "success"); }
      catch (e) { notice(e.message, "error"); }
      return;
    }
    const cancel = event.target.closest("[data-cancel-order]");
    if (cancel) {
      if (!confirm(`Отменить заказ ${cancel.dataset.cancelOrder}? Билеты вернутся в доступные места.`)) return;
      try { await api(`/api/admin/orders/${encodeURIComponent(cancel.dataset.cancelOrder)}/cancel`, { method: "POST", body: "{}" }); await loadOrders(); await loadProducts(); await loadMovements(); await loadOverview(); notice("Бронь отменена, билеты снова доступны.", "success"); }
      catch (e) { notice(e.message, "error"); }
      return;
    }
    if (event.target.closest("#sendTestMail")) {
      try { await api("/api/admin/mail/test", { method: "POST", body: "{}" }); notice("Тестовое письмо отправлено на почту магазина.", "success"); await loadMail(); }
      catch (e) { notice(e.message, "error"); }
      return;
    }
    if (event.target.closest("#refreshMail")) loadMail().catch((e) => notice(e.message, "error"));
  });
  $("#productsRows").addEventListener("click", (event) => {});
  $("#productSearch").addEventListener("input", drawProducts);
  $("#orderSearch").addEventListener("input", drawOrders);
  $("#userSearch").addEventListener("input", drawUsers);
  $("#ordersRows").addEventListener("change", async (event) => {
    const select = event.target.closest("[data-order-status]"); if (!select) return;
    if (select.value === "Отменён") { select.value = orders.find((o) => o.id === select.dataset.orderStatus)?.status || "Забронирован (демо)"; return notice("Для отмены нажми кнопку «Отменить».", "error"); }
    try { const result = await api(`/api/admin/orders/${encodeURIComponent(select.dataset.orderStatus)}`, { method: "PATCH", body: JSON.stringify({ status: select.value }) }); await loadOrders(); await loadOverview(); notice(result.emailSent ? "Статус обновлён, письмо отправлено." : "Статус обновлён. Email пока не отправлен — проверь настройки почты.", result.emailSent ? "success" : ""); }
    catch (e) { notice(e.message, "error"); }
  });
  $("#productForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = event.currentTarget; const data = Object.fromEntries(new FormData(form));
    data.price = Number(data.price); data.stock = Number(data.stock); data.tags = data.tags.split(",").map((x) => x.trim()).filter(Boolean);
    const id = $("#productId").value;
    try { await api(id ? `/api/admin/products/${id}` : "/api/admin/products", { method: id ? "PATCH" : "POST", body: JSON.stringify(data) }); $("#productEditor").classList.add("hidden"); await loadProducts(); await loadOverview(); await loadMovements(); notice(id ? "Матч обновлён." : "Матч добавлен в SQLite.", "success"); }
    catch (e) { notice(e.message, "error"); }
  });
  async function boot() {
    try {
      const auth = await refreshCsrf();
      if (auth.user?.role === "admin") setAuthorized(auth.user);
      else if (auth.user) setUnauthorized("Войдите под аккаунтом администратора. Сейчас активен аккаунт покупателя.");
    } catch { setUnauthorized("Не удалось подключиться к серверу."); }
  }
  boot();
})();
