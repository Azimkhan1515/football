import test from "node:test";
import assert from "node:assert/strict";
import products from "../shared/catalog.json" with { type: "json" };

test("match calendar has distinct fixtures and bookable seat inventory", () => {
  assert.equal(products.length, 12);
  assert.equal(new Set(products.map((item) => item.id)).size, products.length);
  assert.equal(new Set(products.map((item) => item.name)).size, products.length);
  assert.ok(products.every((item) => item.name.includes(" vs ")));
  assert.ok(products.every((item) => Number.isInteger(item.price) && item.price > 0));
  assert.ok(products.every((item) => Number.isInteger(item.stock) && item.stock > 0));
});

test("fixtures include local and international competitions with match details", () => {
  assert.deepEqual([...new Set(products.map((item) => item.category))].sort(), ["international", "kz_premier", "la_liga", "premier", "ucl"]);
  assert.ok(products.every((item) => item.tags.length >= 2));
  assert.ok(products.every((item) => item.specs.some(([label]) => label === "Стадион и город")));
  assert.ok(products.every((item) => item.image.startsWith("https://")));
});

test("match calendar is clearly marked as demo data", () => {
  assert.ok(products.every((item) => item.source.includes("demo-fixtures")));
  assert.ok(products.every((item) => item.delivery.includes("демо") || item.inTheBox.includes("Демонстрационная")));
});
